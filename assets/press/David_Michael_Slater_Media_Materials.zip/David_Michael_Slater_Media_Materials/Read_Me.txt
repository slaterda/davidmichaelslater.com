DAVID MICHAEL SLATER
MEDIA MATERIALS
October 2026

Start with David_Michael_Slater_Press_Kit.pdf. The Word file is the editable companion. Author_Biographies.txt, Interview_Topics.txt, Author_Q_and_A.txt, Book_Facts.txt, and Selected_Praise_and_Coverage.txt provide plain-text copy and sources. Images are in the Images folder. See Image_Credits_and_Sizes.txt for attribution and original dimensions.

This kit contains no full manuscripts or spoiler-filled adaptation pitches.

Contact: david@davidmichaelslater.com
Website: https://www.davidmichaelslater.com
